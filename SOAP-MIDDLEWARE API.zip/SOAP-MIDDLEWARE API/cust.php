<?php   


function url_get_contents_token ($Url,$token) {
    //var_dump($token);
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
      
    $postdata = json_encode($token); 
    $ch = curl_init($Url); //echo $ch;
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    curl_close($ch);
    //print_r ($result);
    return $result;
}

function url_get_contents_card ($Url,$data,$api_token) {
    //var_dump($data);
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }

    $headers = array(
                                'Authorization: '.$api_token,
                                'Content-Type: application/json'
                );
      
    $postdata = json_encode($data);
    $ch = curl_init($Url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    curl_close($ch);
    //print_r ($result);
    return $result;
}


$token = array("password" => "AAC946^%@czr", "username" => "cardtest" );
$url = "https://pblcon-uat.primebank.com.bd:8443/api/v1/user/login"; // TEST Login API URL
$data = url_get_contents_token($url,$token);

$token = json_decode($data);
$tkn_id = $token->data->accessToken;

$url = "https://pblcon-uat.primebank.com.bd:8443/core-api/api/v1/getCustomerDetails";
$request = array(
      
    "accountNumber"=>"2113314006543"

);

$data = url_get_contents_card($url,$request,$tkn_id);
$card_data = json_decode($data);

var_dump($card_data);

//echo "<pre>";print_r($card_data->data->accounts);

echo "A/C Number-".$card_data->data->accounts[0]->accountId.'</br>';
echo "Alternate A/C Number-".$card_data->data->accounts[0]->alternateAccountId.'</br>';
echo "A/C Type-".$card_data->data->accounts[0]->categoryTitle.'</br>';
echo "Branch Name-".$card_data->data->accounts[0]->branchName.'</br>';
echo "Customer Title-".$card_data->data->customerTitle.'</br>';
echo "Customer Type-".$card_data->data->customerType.'</br>';
echo "Email-".$card_data->data->customerEmail.'</br>';
echo "Contact No-".$card_data->data->customerPhone.'</br>';
echo "DOB-".$card_data->data->customerDoB.'</br>';
echo "NID-".$card_data->data->customerNID.'</br>';
echo "Address-".$card_data->data->contactAddress1.'</br>';
echo "Father Name-".$card_data->data->fatherName.'</br>';
echo "Mother Name-".$card_data->data->motherName.'</br>';
echo "Spouse Name-".$card_data->data->spouseName.'</br>';
echo "Nationality-".$card_data->data->nationality.'</br>';
echo "Doc Type-".$card_data->data->docType.'</br>';
echo "Tin-".$card_data->data->tinNumber.'</br>';

echo "RES-".$card_data->responseCode.'</br>';
//echo $card_data->data->branchCode.'</br>';
//echo $card_data->data->accounts[1]->accountId.'</br>';
/*echo $card_data->data->cardDetails[0]->cardType.'</br>';
echo $card_data->data->cardDetails[0]->cardCurrency.'</br>';
echo $card_data->data->cardDetails[0]->availableCash.'</br>';
echo $card_data->data->cardDetails[0]->cardOutstandingBalance.'</br>';
echo $card_data->data->cardDetails[0]->availableBalance.'</br>';
echo $card_data->data->cardDetails[0]->totalLimit.'</br>';
echo $card_data->data->cardDetails[0]->minPaymentDueAmt.'</br>';
echo $card_data->data->cardDetails[0]->lastDueAmt.'</br>';
echo $card_data->data->cardDetails[0]->lastDueDate.'</br>';

*/

?>

