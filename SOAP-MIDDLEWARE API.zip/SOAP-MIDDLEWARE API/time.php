<?php

$time = strftime("%H%M%S %P");


$test = 'Fri, 15 Jan 2016 15:14:10 +0800';
$t = date('Y-m-d H:i:s',strtotime($test));
//echo $t;

$a=(strftime("%I:%M:%S",time() - 6*3600)).'PM';

//echo $a.'</br>';
//$b= $a.'PM';
//echo date("H:i:s", strtotime($a));

date_default_timezone_set("Asia/Dhaka");
echo "The time is " . date("Y-m-d H:i:sa");


$time = strtotime('GMT-6');
$dateInLocal = strftime("%C%y %m %d %H%M%S",$time);

//$dateInLocal = date("Y-m-d H:i:s", $time);

echo $dateInLocal;

?>