<?php   
/*
$url = 'https://api.zippopotam.us/BD/1214';
$proxy = '10.100.100.103:3128';
//$proxyauth = 'user:password';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_HEADER, 1);
$res = curl_exec($ch);
curl_close($ch);

//var_dump($res);  

 $someObject = json_decode($res);
 //var_dump($someObject);
  echo $someObject->country.'<br>';
  echo $someObject->post.'<br>'; // 
  */


function url_get_contents_token ($Url,$data) {
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
      
    $postdata = json_encode($data);
    $ch = curl_init($Url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    curl_close($ch);
    //print_r ($result);
    return $result;
}

function url_get_contents_card ($Url,$data,$api_token) {
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }

    $headers = array(
                                'Authorization: '.$api_token,
                                'Content-Type: application/json'
                );
      
    $postdata = json_encode($data);
    $ch = curl_init($Url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    curl_close($ch);
    //print_r ($result);
    return $result;
}


$token = array("password" => "AAC946^%@czr", "username" => "cardtest" );
$url = "https://pblcon-uat.primebank.com.bd:8443/api/v1/user/login"; // TEST Login API URL
$data = url_get_contents_token($url,$token);

$token = json_decode($data);
$tkn_id = $token->data->accessToken;

$url = "https://pblcon-uat.primebank.com.bd:8443/card-api/v1/card/details";
$request = array(
      "requestDateTime" => date("d/m/Y"),
      "requestId" => "20210128MPP0000056",
      "sourceChannel" => "MIB",
      "transactionId" => "transactionId",
      "cardNumber" => "2v4uFoWoVQ//bj1YpH7ueWU+XXK2L8I1Ztvy9IbZqyg=",
      "cardCurrency" => "050"

);

$data = url_get_contents_card($url,$request,$tkn_id);
$card_data = json_decode($data);
//var_dump($card_data);
//echo "<pre>";print_r($card_data->data->cardDetails);

echo $card_data->data->cardNumber.'</br>';
echo $card_data->data->cardDetails[0]->embossName.'</br>';
echo $card_data->data->cardDetails[0]->cardType.'</br>';
echo $card_data->data->cardDetails[0]->cardCurrency.'</br>';
echo $card_data->data->cardDetails[0]->availableCash.'</br>';
echo $card_data->data->cardDetails[0]->cardOutstandingBalance.'</br>';
echo $card_data->data->cardDetails[0]->availableBalance.'</br>';
echo $card_data->data->cardDetails[0]->totalLimit.'</br>';
echo $card_data->data->cardDetails[0]->minPaymentDueAmt.'</br>';
echo $card_data->data->cardDetails[0]->lastDueAmt.'</br>';
echo $card_data->data->cardDetails[0]->lastDueDate.'</br>';



?>

