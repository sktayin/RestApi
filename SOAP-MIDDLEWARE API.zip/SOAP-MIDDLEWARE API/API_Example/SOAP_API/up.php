<?php
$a='00000200380';
$b='NAFIZ';
$c='TITAS';
$d='VR00000000000001';
$e='ENCAT2';
$soap_request = '<soapenv:Envelope 
xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
xmlns:v2="http://www.fisglobal.com/services/prepaid/IssuerDirectives/V2_0_0" 
xmlns:com="http://www.fisglobal.com/services/prepaid/common">
<soapenv:Header/>
   <soapenv:Body>
      <v2:IssDirective2Request>
        <com:RqstHdr>
            <com:RqstHdrVer>1.0.0</com:RqstHdrVer>
            <com:RqUID>202010071511001</com:RqUID>
            <com:SrcId>WEB</com:SrcId>
            <com:TestInd>N</com:TestInd>
            <com:LocalePref>en-EN</com:LocalePref>
            <com:Security>
              <com:WsSec>Y</com:WsSec>
            </com:Security>
            <com:SvcParamsLst>
              <com:SvcParams>
                <com:FeId>PRIM</com:FeId>
                <com:SvcId>accload</com:SvcId>
                <com:SvcVer>1.0.1</com:SvcVer>
                <com:ApplId>CTX</com:ApplId>
              </com:SvcParams>
            </com:SvcParamsLst>
          </com:RqstHdr>
         <v2:IssDirective2Osi>
            
            <v2:RecId>2020100701</v2:RecId>
            <v2:Action>6</v2:Action>
            <v2:InstCode>PRIM</v2:InstCode>
            <v2:CustDet>
               
               <v2:Custcode>'.$a.'</v2:Custcode>
           
               <v2:LastName>'.$b.'</v2:LastName>
          
               <v2:FirstName>'.$c.'</v2:FirstName>
         
            
            </v2:CustDet>
            <v2:CrdDet>
               <v2:CardAlias>'.$d.'</v2:CardAlias>
               <v2:IssRiskCat>'.$e.'</v2:IssRiskCat>

            
            </v2:CrdDet>
         </v2:IssDirective2Osi>
      </v2:IssDirective2Request>
   </soapenv:Body>
</soapenv:Envelope>';




        $headers = array(
            "Content-type: text/xml",
            "Accept: text/xml",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
            "SOAPAction:" . "IssDirective2:GetCustAccCardDetailsRqstMsg",
            "Content-length: " . strlen($soap_request),
        );

        $url = "https://10.1.32.13:7045/fis-intg-Prime/services/ws/unsecured?";
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $soap_request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);

       
        $myXMLData=htmlentities(curl_exec($ch), $flags = ENT_HTML401, $encoding = ini_get("default_charset"));
        curl_close($ch);
        

       //echo $myXMLData;

      var_dump($myXMLData);
  /*$xml = str_replace(['&lt;', '&gt;'], ['<', '>'], $myXMLData);


                    $ms = strpos($xml, "~");
                    
                    if($ms>0) {
                    $data['appErr']=1;
                    $data['msg']=$xml;
                    

                    }else{

                    $s = strpos($xml, "<ns11:GetCustAccCardDetailsOso>");  echo $s."</br>";
                    $e = strpos($xml, "</ns11:GetCustAccCardDetailsOso>"); echo $e."</br>";
                    $f = strlen('</ns11:GetCustAccCardDetailsOso>'); echo $f."</br>";
                    $dif = $e - $s + $f ; echo $dif."</br>";
                    $xml = substr($xml, $s, $dif); //echo $xml."</br>";
                    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . str_replace('ns11:', '', $xml);
                    $data['appErr']=0;
                	}
                    $xmll = @simplexml_load_string($xml);

			  foreach($xmll->children() as $child) {
              				echo $child->LastName;

          				}*/
?>