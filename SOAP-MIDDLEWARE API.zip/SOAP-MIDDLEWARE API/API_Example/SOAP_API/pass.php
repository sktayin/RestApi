<?php
$acct ='PA00000000000026';
$soap_request = '<soapenv:Envelope 
xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
xmlns:v1="http://www.fisglobal.com/services/prepaid/CustomerAccountCard/V1_0_2" 
xmlns:com="http://www.fisglobal.com/services/prepaid/common">
   <soapenv:Header/>
   <soapenv:Body>
      <v1:GetCustAccCardDetailsRequest>
           <com:RqstHdr>
            <com:RqstHdrVer>1.0.0</com:RqstHdrVer>
            <com:RqUID>12323-23232-dsfsdf-32432</com:RqUID>
            <com:SrcId>WEBSER</com:SrcId>
            <com:TestInd>N</com:TestInd>
            <com:LocalePref>en-EN</com:LocalePref>
            <com:Security>
            <com:WsSec>Y</com:WsSec>
            </com:Security>
            <com:SvcParamsLst>
              <com:SvcParams>
                  <com:FeId>YRBL</com:FeId>
                 <com:SvcId>GetCard</com:SvcId>
                  <com:SvcVer>1.0.1</com:SvcVer>
                  <com:ApplId>CTX</com:ApplId>
               </com:SvcParams>
            </com:SvcParamsLst>
         </com:RqstHdr>
         <v1:GetCustCardAccDetailsOsi>
           
           <com:AccountId>
              <com:InstCode>PRIM</com:InstCode>
               <com:AccNo>'.$acct.'</com:AccNo>
               <com:CurrCode>050</com:CurrCode>
            </com:AccountId>
  
           <v1:ReturnCard>1</v1:ReturnCard>
         </v1:GetCustCardAccDetailsOsi>
      </v1:GetCustAccCardDetailsRequest>
   </soapenv:Body>
</soapenv:Envelope>';




        $headers = array(
            "Content-type: text/xml",
            "Accept: text/xml",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
            "SOAPAction:" . "CustomerAccountCard:GetCustAccCardDetailsRqstMsg",
            "Content-length: " . strlen($soap_request),
        );

        $url = "https://10.1.32.13:7045/fis-intg-Prime/services/ws/unsecured?";
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $soap_request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);

       
        $myXMLData=htmlentities(curl_exec($ch), $flags = ENT_HTML401, $encoding = ini_get("default_charset"));
        curl_close($ch);


  	   //echo $myXMLData;

      var_dump($myXMLData);
  /*$xml = str_replace(['&lt;', '&gt;'], ['<', '>'], $myXMLData);


                    $ms = strpos($xml, "~");
                    
                    if($ms>0) {
                    $data['appErr']=1;
                    $data['msg']=$xml;
                    

                    }else{

                    $s = strpos($xml, "<ns11:GetCustAccCardDetailsOso>");  echo $s."</br>";
                    $e = strpos($xml, "</ns11:GetCustAccCardDetailsOso>"); echo $e."</br>";
                    $f = strlen('</ns11:GetCustAccCardDetailsOso>'); echo $f."</br>";
                    $dif = $e - $s + $f ; echo $dif."</br>";
                    $xml = substr($xml, $s, $dif); //echo $xml."</br>";
                    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . str_replace('ns11:', '', $xml);
                    $data['appErr']=0;
                	}
                    $xmll = @simplexml_load_string($xml);

			  foreach($xmll->children() as $child) {
              				echo $child->LastName;

          				}*/
?>