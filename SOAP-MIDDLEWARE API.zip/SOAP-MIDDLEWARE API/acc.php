<?php

$cardno= '4731930000009882';

$fd= '2021-11-01';

$td= '2022-03-20';

$soap_request = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://www.fisglobal.com/services/prepaid/GetAccItems/V1_0_1" xmlns:com="http://www.fisglobal.com/services/prepaid/common">
   <soapenv:Header/>
   <soapenv:Body>
      <v1:GetAccItemsRequest>
          <com:RqstHdr>
            <com:RqstHdrVer>1.0.0</com:RqstHdrVer>
            <com:RqUID>988df6a3-8bd6-495e-8373-05bd4671ccfb</com:RqUID>
            <com:SrcId>WEBSER</com:SrcId>
            <com:TestInd>N</com:TestInd>
            <com:LocalePref>en-EN</com:LocalePref>
            <com:Security>
              <com:WsSec>N</com:WsSec>
            </com:Security>
            <com:SvcParamsLst>
               <!--1 or more repetitions:-->
               <com:SvcParams>
                  <com:FeId>YRBL</com:FeId>
                  <com:SvcId>GetAccItems</com:SvcId>
                  <com:SvcVer>1.0.1</com:SvcVer>
                  <com:ApplId>CTX</com:ApplId>
               </com:SvcParams>
            </com:SvcParamsLst>
         </com:RqstHdr>
        <v1:GetAccItemsOsi>
             <com:PageCntrl>
				<com:OffSet>1</com:OffSet>
				<com:PageSize>3000</com:PageSize>
			 </com:PageCntrl>
             <com:RetInfoList>
             		<com:RspFld>AmBill</com:RspFld>
             		<com:RspFld>AmTxn</com:RspFld>
             		<com:RspFld>AmtBillCom</com:RspFld>
             		<com:RspFld>Blkamt</com:RspFld>
             		<com:RspFld>OpenToBuy</com:RspFld>
             		<com:RspFld>AvlBal</com:RspFld>
             		<com:RspFld>DateLocal</com:RspFld>
                    <com:RspFld>TimeLocal</com:RspFld>
                    <com:RspFld>CrDb</com:RspFld>
                    <com:RspFld>CardIds</com:RspFld>  
                    <com:RspFld>Description</com:RspFld>

             </com:RetInfoList>
             <com:SearchCriteria>
             	 <com:InstCode>PRIM</com:InstCode>
             	 <com:CardId>
                 <com:PAN>'.$cardno.'</com:PAN>
                 </com:CardId>
              	 <com:StartDate>'.$fd.'</com:StartDate>
              	 <com:EndDate>'.$td.'</com:EndDate>
             </com:SearchCriteria>
             <com:OrderBy>3</com:OrderBy>
            
           </v1:GetAccItemsOsi>
      </v1:GetAccItemsRequest>
   </soapenv:Body>
</soapenv:Envelope>';

/*ORDER BY LOCAL DATE TIME = 1;          [DESC]
ORDER BY CTXDATE  = 2;                 [DESC]
ORDER BY LOCAL DATE_TIME_ASC = 3;     [ASC]
ORDER BY CTXDATE_ASC    4;             [ASC]

Default LOCAL DATE TIME = 1
*/



        $headers = array(
            "Content-type: text/xml",
            "Accept: text/xml",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
            "SOAPAction:" . "GetAccItems:GetAccItemsRqstMsg",
            "Content-length: " . strlen($soap_request),
        );
        $url = "https://10.1.32.13:7045/fis-intg-Prime/services/ws/unsecured?";
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $soap_request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);

        //$myXMLData = curl_exec($ch);
        $myXMLData=htmlentities(curl_exec($ch), $flags = ENT_HTML401, $encoding = ini_get("default_charset"));
        curl_close($ch);

        var_dump($myXMLData);


?>