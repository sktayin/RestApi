<?php

function url_get_contents_token () {
    $token = array("password" => "AAC946^%@czr", "username" => "cardtest" );
    $url = "https://pblcon-uat.primebank.com.bd:8443/api/v1/user/login";
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
      
    $postdata = json_encode($token); 
    $ch = curl_init($url); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
   
    $result = curl_exec($ch);
    
     if ($result === false)
        {  
            print_r('Curl error: ' . curl_error($ch));
            die;
        }
        curl_close($ch);
        var_dump($result);
 
}

url_get_contents_token ();
?>