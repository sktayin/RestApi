<?php 



	$name = $_POST['name'];
	$status = $_POST['status'];

	


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ivr";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE cdr SET status= '".$status."' WHERE agent='".$name."'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>



  
	

