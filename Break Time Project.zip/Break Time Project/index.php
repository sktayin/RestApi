<form action="action.php" method="post">
  <label for="name">Name:</label>
  <input type="text" id="fname" name="name"><br><br>
  <label for="status">Status:</label>
  <input type="text" id="lname" name="status"><br><br>
  <input type="submit" value="submit">
</form>