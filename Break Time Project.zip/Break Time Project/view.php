<?php
$url=$_SERVER['REQUEST_URI'];
header("Refresh: 5; URL=$url");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ivr";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
$query = mysqli_query($con,"SELECT * FROM cdr where agent='1005'");
foreach($query as $row){
	
	$ID = $row["agent"];
	$ST = $row["status"];


	if ($ST == 'inactive' ) {
		session_start();
		if(!isset($_SESSION['timer'])){
    	$_SESSION['timer'] = time();

		}
	}else{
		session_start();
		session_destroy();
	}
 	echo $_SESSION['timer'].'<br>';
	$now = time();

	echo $now.'<br>';

	$timeSince = $now - $_SESSION['timer'];

	echo $timeSince." seconds have passed.";

	if ($ST != 'inactive' && $_SESSION['timer']){
		$sql = mysqli_query($con,"INSERT INTO brk (agent, duration) VALUES ('".$ID."', '".$timeSince."')");
		//echo $timeSince;

	}

}

?>
