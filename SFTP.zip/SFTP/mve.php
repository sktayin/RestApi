<?php
    
$fileList = glob('*.txt');
foreach($fileList as $filename){
    if(is_file($filename)){
        //echo $filename, '<br>';
        $filePath= 'C:/xampp/htdocs/SFTP/'.$filename;
        $destinationFilePath = 'mv/'.$filename;
        if( !rename($filePath, $destinationFilePath) ) {  
    echo "File can't be moved!";  
}else {  
    echo "File has been moved!";  
} 
    }   
}

?>