<?php
	error_reporting(0);
    $files = glob("C:/xampp/htdocs/SFTP/*.txt");
    //$output = "result.txt";

    //print_r($files);

    foreach($files as $file) {
        //$content = file_get_contents($file);

        //echo $file;
        //file_put_contents($output, $content, FILE_APPEND);

        $open = fopen($file,'r');


        while (!feof($open)) 
{
	$getTextLine = fgets($open);
	$explodeLine = explode("|",$getTextLine);
	
	list($name,$city) = $explodeLine;
// $qry = "insert into empoyee_details (name, city,postcode,job_title) values('".$name."','".$city."','".$postcode."','".$job_title."')";

	//mysqli_query($conn,$qry);
	echo $name.'</br>';

	echo $city;
	
	
}
 
fclose($open);

    }
?>